/*
ADVANTAGES/DISADVANTAGES LINKED LIST
Advantages: dynamic size, flexibility, faster deletion and insertion, no memory wastage, no contiguous memory, flexible with data types
disadvantages: slower access because there is no constant time access, higher memory because of pointers, more complex to implement

ADVANTAGES/DISADVANTAGES ARRAY
Advantages: fixed size, faster access, faster search, faster insertion, faster deletion (O(1) time complexity)
disadvantages: fixed size, no flexibility, slower search, need contiguous memory, memory wastage, harder to inset and delete
*/

#include <iostream>
#include <string>
#include "runGame.h"

using namespace std;


int main()
{
    //load profiles into array
    string userName, newCommandToAdd, newCommandDescription, oldCommandTodelete;
    int selection, userIndex;

    string filename = "profiles.csv";
    ArrayNode<string, int> array[50];
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error: Could not open the file: " << filename << std::endl;
        return false;
    }

    std::string line;
    int index = 0;
    while (std::getline(file, line)) {
        if (line.empty()) {
            continue; // Skip empty lines
        }

        std::stringstream ss(line);
        std::string name;
        std::string points;

        // Parse the line into command and description
        if (std::getline(ss, name, ',') && std::getline(ss, points)) {
            array[index].setName(name);
            array[index].setData(std::stoi(points));
            array[index].setIndex(index);
            index++;

            // Check for exceeding array capacity
            if (index >= 50) {
                std::cerr << "Error: Exceeded array capacity!" << std::endl;
                break;
            }
        } else {
            std::cerr << "Error: Invalid line format: " << line << std::endl;
        }
    }

    int size = index + 1;
    file.close();

// load commands into linked list
    LinkedList<string, string> list;
    list.readFile("commands.csv");

// create game object
    runGame game;

int played = 0;

// start main menu loop
    while (true)
    {
        std::cout << "Please select an option listed below:\n";
        std::cout << "1. Game Rules\n2. Play Game\n3. Load Previous Game\n4. Add Command\n5. Remove Command\n6. Exit\n";
        std::cout << "Your selection: ";
        std::cin >> selection;     

        if (std::cin.fail()) // the input is not an integer
        {
            std::cout << "Your selection is invalid. Please select again." << endl;
            std::cout << "=============================================================================" << endl << endl;
            std::cin.clear();
            std::cin.ignore();
        }
        else
        {
            switch (selection)
            {
                case 1: // Game Rules
                {
                    std::cout << "================================= Game Rule ===================================" << endl;
                    std::cout << "To play the game, select \"2\" where you will be prompted for your name and number of questions.\n";
                    std::cout << "Each question presents a specific Linux command where you will be able to choose from 3 different options. Each correct answer yields a point.\n";
                    std::cout << "You can also add and delete commands as needed.\n";
                    std::cout << "================================= Game Rule ===================================" << endl << endl;

                    break;
                }

                case 2: 
                {
                    if (played == 0) {
                        std::cout << "Welcome to the game! Please enter your name: ";
                        std::cin >> userName;
                        played++;
                        array[size].setName(userName);
                        array[size].setData(0);
                    }
                    else {
                    }
                    
                    game.Run(userName, array[size].getData(), list, array[size]);

                    break;

                }
                
                
                case 3: // 2. Play Game; 3. Load Previous Game
                {

                    if (played != 0) {
                        std::cout << "are you sure you want to continue, you will lose you current profile if you do (enter 0 to continue to loading profiles or enter 1 and exit game to save)" << endl;
                        std::cin >> played;
                        break;
                    }
                    
                    if(played == 0)
                    {
                        for (int i = 0; i < size; i++) {
                            std::cout << i << ". Name: " << array[i].getName() << ", Points: " << array[i].getData() << std::endl;
                        }

                        int profileNumber;

                        std::cout << "which profile would you like to load?(please enter the index number): ";
                        std::cin >> profileNumber;

                        userIndex = profileNumber - 1;

                        userName = array[userIndex].getName();
                        int points = array[userIndex].getData();

                        game.Run(userName, points, list, array[profileNumber]);
                        
                    }
                    

                    

                    break;
                }

                case 4: // Add Command
                {
                    std::cout << "To add a command to the library, please enter the command name that you would add: ";
                    std::cin >> newCommandToAdd;
                    std::cout << "Please enter the description of the command: ";
                    std::cin >> newCommandDescription;
                    list.insertAtBack(newCommandToAdd, newCommandDescription);
                    
                    break;
                }

                case 5: // Remove Command
                {
                    std::cout << "Please enter the name of the command that you would remove: ";
                    std::cin >> oldCommandTodelete;
                    list.deleteNode(oldCommandTodelete);
                    
                    break;
                }
                    
                case 6: // Exit
                {
                    std::cout << "Thank you for playing the game! Goodbye!" << endl;

                    std::ofstream file("profiles.csv");
                    if (!file.is_open()) {
                        std::cerr << "Error: Could not open the file: " << filename << std::endl;
                    } else{

                        for (int i = 0; i < size; i++) {
                            file << array[i].getName() << "," << array[i].getData() << std::endl;
                        }

                        file.close();
                        std::cout << "Array saved to file: " << filename << std::endl;
                    }

                    list.saveToFile("commands.csv");

                    return 0;
                }


            } // end of switch(selection)
        } // end of else: check (cin.fail())
        
    } // end of while(true)
} // end of int main()


