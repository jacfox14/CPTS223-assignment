#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>



// Template class: the node in the linked list
template <typename T1, typename T2>
class Node {
public:
    // Default constructor
    Node() : next(nullptr) {}

    // Parameterized constructor
    Node(T1 name, T2 data) : name(name), data(data), next(nullptr) {}

    // Getters
    T1 getName() const {
        return name;
    }

    T2 getData() const {
        return data;
    }

    // Setters
    void setName(T1 newName) {
        name = newName;
    }

    void setData(T2 newData) {
        data = newData;
    }

    // Pointer to the next node
    Node* getNext() const {
        return next;
    }

    void setNext(Node* nextNode) {
        next = nextNode;
    }

private:

    T1 name;  // Holds the name or key of the node
    T2 data;  // Holds the data or value of the node
    Node* next;  // Pointer to the next node in the list

};

// LinkedList class template
template <typename T1, typename T2>
class LinkedList {
public:

    LinkedList() : Head(nullptr) {}

    // Insert a node at the front of the list
    bool insertAtFront(T1 name, T2 data) {
        Node<T1, T2>* newNode = new Node<T1, T2>(name, data);
        if (!newNode) return false; // Check for memory allocation failure

        newNode->setNext(Head);
        Head = newNode;
        return true;
    }

    // Insert a node at the back of the list
    bool insertAtBack(T1 name, T2 data) {
        Node<T1, T2>* newNode = new Node<T1, T2>(name, data);
        if (!newNode) return false; // Check for memory allocation failure

        if (Head == nullptr) {
            Head = newNode;
            return true;
        }

        Node<T1, T2>* current = Head;
        while (current->getNext() != nullptr) {
            current = current->getNext();
        }
        current->setNext(newNode);
        return true;
    }

    // Display the list
    void display() const {
        Node<T1, T2>* current = Head;
        while (current != nullptr) {
            std::cout << "[" << current->getName() << ": " << current->getData() << "] -> ";
            current = current->getNext();
        }
        std::cout << "null" << std::endl;
    }

    // Destructor to free the list memory
    ~LinkedList() {
        Node<T1, T2>* current = Head;
        Node<T1, T2>* nextNode = nullptr;
        while (current != nullptr) {
            nextNode = current->getNext();
            delete current;
            current = nextNode;
        }
        Head = nullptr;
    }

    bool readFile(const std::string& filename) {
        
        std::ifstream file(filename);

        if (!file.is_open()) {
            std::cerr << "Error: Could not open the file: " << filename << std::endl;
            return false;
        }

        std::string line;
        while (std::getline(file, line)) {
            std::stringstream ss(line);
            std::string command, description;

            // Parse the line into command and description
            if (std::getline(ss, command, ',') && std::getline(ss, description)) {
                // Remove any leading/trailing spaces or quotes from the description
                description.erase(0, description.find_first_not_of("\" "));
                description.erase(description.find_last_not_of("\" ") + 1);

                // Insert the command and description into the linked list
                insertAtBack(command, description);
            }
        }

        file.close();
        return true;


    }

    int getSize() {
        int size = 0;
        Node<T1, T2>* current = Head;
        while (current != nullptr) {
            size++;
            current = current->getNext();
        }
        return size;
    }

    Node<T1, T2> getIndex(int index) {
        Node<T1, T2>* current = Head;
        for (int i = 0; i < index; i++) {
            current = current->getNext();
        }
        return *current;
    }

    bool saveToFile(const std::string& filename) const {
        std::ofstream file(filename);

        if (!file.is_open()) {
            std::cerr << "Error: Could not open the file: " << filename << std::endl;
            return false;
        }

        Node<T1, T2>* current = Head;
        while (current != nullptr) {
            file << current->getName() << ",\"" << current->getData() << "\"" << std::endl;
            current = current->getNext();
        }

        file.close();
        std::cout << "List saved to file: " << filename << std::endl;
        return true;
    }

    void deleteNode(T1 name) {
        Node<T1, T2>* current = Head;
        Node<T1, T2>* previous = nullptr;

        while (current != nullptr) {
            if (current->getName() == name) {
                if (previous == nullptr) {
                    Head = current->getNext();
                } else {
                    previous->setNext(current->getNext());
                }
                delete current;
                return;
            }
            previous = current;
            current = current->getNext();
        }
    }

private:
    Node<T1, T2>* Head;
};

