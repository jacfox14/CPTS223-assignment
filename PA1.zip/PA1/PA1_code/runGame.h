#pragma once
#include "linkedList.h"
#include "array.h"
#include <ctime>
#include <cstdlib>
#include <algorithm>

using namespace std; 

class runGame
{
    
public:
    
    runGame();
    void Run(std::string name, int points, LinkedList<std::string, std::string> &list, ArrayNode<std::string, int> profile);

};

runGame::runGame()
{
}


void runGame::Run(std::string name, int points, LinkedList<std::string, std::string> &list, ArrayNode<std::string, int> profile)
{
    int keepPlaying = 1;
    do{

        int finalPoints = points;
        int answer;

        std::cout << "Welcome " << name << "!" << std::endl;
        std::cout << "You have " << points << " points." << std::endl;

        int randomIndex = rand() % list.getSize();
        int randomWrongIndex1;
        int randomWrongIndex2;

        // Ensure that randomWrongIndex1 is different from randomIndex
        do {
            randomWrongIndex1 = rand() % list.getSize();
        } while (randomWrongIndex1 == randomIndex);

        // Ensure that randomWrongIndex2 is different from randomIndex and randomWrongIndex1
        do {
            randomWrongIndex2 = rand() % list.getSize();
        } while (randomWrongIndex2 == randomIndex || randomWrongIndex2 == randomWrongIndex1);

        std::cout << "The command is: " << list.getIndex(randomIndex).getName() << endl;
        std::cout << "Which is the correct option? (Enter a number 1-3)" << endl;

        // Create an array with the correct and incorrect options and shuffle it
        int indexArray[3] = { randomIndex, randomWrongIndex1, randomWrongIndex2 };
        std::random_shuffle(std::begin(indexArray), std::end(indexArray));

        // Display the options
        for (int i = 0; i < 3; i++) {
            std::cout << i + 1 << ". " << list.getIndex(indexArray[i]).getData() << endl;
        }

        // Take user input
        std::cin >> answer;

        // Check if the chosen option corresponds to the correct command
        if (indexArray[answer - 1] == randomIndex) {
            std::cout << "Correct!" << endl;
            finalPoints += 1;
        } else {
            std::cout << "Incorrect!" << endl;
            finalPoints -= 1;
        }

        std::cout << "Your final score: " << finalPoints << " points." << endl;
        std::cout << "Would you like to play again? (Enter 0 for No, and any other nuumber for Yes)" << endl;
        std::cin >> keepPlaying;

    } while (keepPlaying != 0);
    
    std::cout << "Thank you for playing!" << endl;
}