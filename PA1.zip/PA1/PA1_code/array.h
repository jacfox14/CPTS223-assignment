#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

template <typename T1, typename T2>
class ArrayNode {
public:

    // Default constructor
    ArrayNode() : index(-1) {}

    ArrayNode(T1 name, T2 data) : name(name), data(data), index(-1) {}

    T1 getName() const { return name; }
    void setName(T1 name) { this->name = name; }

    T2 getData() const { return data; }
    void setData(T2 data) { this->data = data; }

    void setIndex(int index) { this->index = index; }
    int getIndex() const { return index;}

private:

    T1 name;  // Holds the name or key of the node
    T2 data;
    int index;

};

/** 
template <typename T1, typename T2>
class Array {
public:

    ArrayNode<T1, T2> array[MAX_SIZE];
    // Constructor initializes size to 0
    Array() : size(0) {}

    // Retrieve an ArrayNode at a specific index
    ArrayNode<T1, T2> getArrayNode(int index) const {
        if (index >= 0 && index < size) {
            return array[index];
        } else {
            throw std::out_of_range("Index out of range");
        }
    }

    // Read CSV file and populate the array with commands and descriptions
    bool readFile(const std::string& filename) {
        std::ifstream file(filename);
        if (!file.is_open()) {
            std::cerr << "Error: Could not open the file: " << filename << std::endl;
            return false;
        }

        std::string line;
        int index = 0;
        while (std::getline(file, line)) {
            if (line.empty()) {
                continue; // Skip empty lines
            }

            std::stringstream ss(line);
            std::string name;
            std::string points;

            // Parse the line into command and description
            if (std::getline(ss, name, ',') && std::getline(ss, points)) {
                array[index] = ArrayNode<T1, T2>(name, points, index);
                index++;

                // Check for exceeding array capacity
                if (index >= MAX_SIZE) {
                    std::cerr << "Error: Exceeded array capacity!" << std::endl;
                    break;
                }
            } else {
                std::cerr << "Error: Invalid line format: " << line << std::endl;
            }
        }

        size = index;
        file.close();
        return true;
    }

    // Display the contents of the array
    void display() const {
        for (int i = 0; i < size; i++) {
            std::cout << "[" << array[i].getName() << ": " << array[i].getData() << "]\n";
        }
        std::cout << "null" << std::endl;
    }

private:
    int size;  // Number of valid entries in the array
};
*/